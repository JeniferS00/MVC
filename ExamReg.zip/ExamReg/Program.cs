namespace Application;

class Program
{
    static void Main(string []args)
    {
        Startup.Config(args);
    }
}