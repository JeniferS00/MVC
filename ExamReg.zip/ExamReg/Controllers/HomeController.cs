﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Application.Models;
using System.Data.SqlClient;
using System.Data;
using Serilog;


namespace Application.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.Console()
            .WriteTo.File("logs/app.txt",rollingInterval: RollingInterval.Day)
            .CreateLogger();
    }
    public IActionResult Panel(){
        return View();
    }

    public IActionResult Index()
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            return View();
        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }
    public IActionResult AdminIndex()
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            return View();
        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }

    public IActionResult Login()
    {
        return View();
    }

    [ActionName("Login")]
    [HttpPost]
    public IActionResult Login(Login login)
    {
        SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
        if(login.UserID !=null && login.Password!=null)
        {
            try
            {
                sqlconnection.Open();

                SqlCommand sqlCommand = sqlconnection.CreateCommand();

                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "Authentication";

                SqlParameter inputUserid = sqlCommand.Parameters.Add("@InUserID",SqlDbType.VarChar);
                inputUserid.Direction = ParameterDirection.Input;
                inputUserid.Value = login.UserID;

                SqlParameter inputPassword = sqlCommand.Parameters.Add("@InPassword",SqlDbType.VarChar);
                inputPassword.Direction = ParameterDirection.Input;
                inputPassword.Value = login.Password; 

                SqlParameter existOutput = sqlCommand.Parameters.Add("Exist",SqlDbType.VarChar,30);
                existOutput.Direction = ParameterDirection.Output;            

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                sqlDataReader.Close();
                
                if(sqlCommand.Parameters["Exist"].Value.ToString() == "Admin")
                {
                    TempData["LoginMessage"] = "Successfully Loggedin!!";
                    HttpContext.Session.SetString("MainUserID","Admin");
                    return RedirectToAction("Index","Home");
                }
                else if(sqlCommand.Parameters["Exist"].Value.ToString() == "User")
                {
                    TempData["LoginMessage"] = "Successfully Loggedin!!";
                    HttpContext.Session.SetString("MainUserID",login.UserID);
                    return RedirectToAction("Index","Home");
                }                
                else
                {
                    ViewBag.Notification = "Wrong UserName or Password";
                    return View();           
                }
            }
            catch (SqlException exception)
            {
                Log.Error(exception.ToString());
                return View();
            }
            finally
            {
                sqlconnection.Close();
                Log.CloseAndFlush();
            } 
        } 
        return View();
    }

    public IActionResult Register()
    {
        return View();
    }

    [ActionName("Register")]
    [HttpPost]
    public IActionResult Register(Register register)
    {
        SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
        SqlCommand sqlCommand = new SqlCommand();
        
        if(register.UserID !=null && register.Password!=null && register.PhoneNumber != null)
        {
            try
            {
                sqlconnection.Open();
                sqlCommand.Connection = sqlconnection; 

                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "Register";

                SqlParameter inputNewUserid = sqlCommand.Parameters.Add("@NewUserID",SqlDbType.VarChar);
                inputNewUserid.Direction = ParameterDirection.Input;
                inputNewUserid.Value = register.UserID;

                SqlParameter inputNewUserName = sqlCommand.Parameters.Add("@NewUserName",SqlDbType.VarChar);
                inputNewUserName.Direction = ParameterDirection.Input;
                inputNewUserName.Value = register.UserName;

                SqlParameter inputPhoneNumber = sqlCommand.Parameters.Add("@NewPhoneNumber",SqlDbType.VarChar);
                inputPhoneNumber.Direction = ParameterDirection.Input;
                inputPhoneNumber.Value = register.PhoneNumber;
                
                if(register.Password.Equals(register.ConfirmPassword))
                {
                    SqlParameter inputUserPassword = sqlCommand.Parameters.Add("@NewPassword",SqlDbType.VarChar);
                    inputUserPassword.Direction = ParameterDirection.Input;
                    inputUserPassword.Value = register.Password;
                }
                else
                {
                    ViewBag.Notification = "Register Failed!!";
                    return View();
                }

                SqlParameter existOutput = sqlCommand.Parameters.Add("Success",SqlDbType.VarChar,30);
                existOutput.Direction = ParameterDirection.Output;

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                sqlDataReader.Close();

                if(sqlCommand.Parameters["Success"].Value.ToString() == "Existing User")
                {
                    ViewBag.Notification = "User data already exists";
                    return View();
                }                
                else if(sqlCommand.Parameters["Success"].Value.ToString() == "Account Created")
                {
                    TempData["RegisterMessage"] = "Account Created!!";
                    return RedirectToAction("Login","Home");                    
                }
                else
                {
                    ViewBag.Notification = "Register Failed!!";
                    return View();                        
                }
            }
            catch (SqlException exception)
            {
                if(exception.Number==1062)
                {
                    ViewBag.Notification = "Duplicate entry not accepted. Please check the entries.";
                }
                Log.Error(exception.ToString());
                return View();
            }
            finally
            {
                sqlconnection.Close();
                Log.CloseAndFlush();
            }
        }
        return View();
    }

    public IActionResult Test()
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
            try
            {
                sqlconnection.Open();

                SqlCommand sqlCommand = sqlconnection.CreateCommand();

                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "ViewExam";

                SqlParameter inputUserid = sqlCommand.Parameters.Add("@InUserID",SqlDbType.VarChar);
                inputUserid.Direction = ParameterDirection.Input;
                inputUserid.Value = HttpContext.Session.GetString("MainUserID");

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                ViewBag.Exam = sqlDataReader;
                return View();
            }
            catch (SqlException exception)
            {
                Log.Error(exception.ToString());
                return View();
            }
            finally
            {
                Log.CloseAndFlush();
            } 

        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }

    [HttpPost]
    public IActionResult Test(ExamRegister examRegister)
    {
        // return Content(examRegister.ExamModel + " " + examRegister.DepartmentName + " " + examRegister.SubjectName);
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
            try
            {
                sqlconnection.Open();

                SqlCommand sqlCommand = sqlconnection.CreateCommand();

                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "RegisterExam";

                SqlParameter inputUserid = sqlCommand.Parameters.Add("@InUserID",SqlDbType.VarChar);
                inputUserid.Direction = ParameterDirection.Input;
                inputUserid.Value = HttpContext.Session.GetString("MainUserID");

                SqlParameter inputExamModel = sqlCommand.Parameters.Add("@InExamModel",SqlDbType.VarChar);
                inputExamModel.Direction = ParameterDirection.Input;
                inputExamModel.Value = examRegister.ExamModel;

                SqlParameter inputDepartmentName = sqlCommand.Parameters.Add("@InDepartmentName",SqlDbType.VarChar);
                inputDepartmentName.Direction = ParameterDirection.Input;
                inputDepartmentName.Value = examRegister.DepartmentName;

                SqlParameter inputSubjectName = sqlCommand.Parameters.Add("@InSubjectName",SqlDbType.VarChar);
                inputSubjectName.Direction = ParameterDirection.Input;
                inputSubjectName.Value = examRegister.SubjectName;

                SqlParameter existOutput = sqlCommand.Parameters.Add("Exists",SqlDbType.VarChar,30);
                existOutput.Direction = ParameterDirection.Output;

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();


                if(sqlCommand.Parameters["Exists"].Value.ToString() == "Already Exists")
                {
                    ViewBag.Notification = "Test has been already registered";
                    return View();
                }                
                else if(sqlCommand.Parameters["Exists"].Value.ToString() == "Success")
                {
                    TempData["TestMessage"] = "Test registered";
                    return RedirectToAction("Index","Home");
                }
                else
                {
                    return View();
                }
            }
            catch (SqlException exception)
            {
                Log.Error(exception.ToString());
                return View();
            }
            finally
            {
                Log.CloseAndFlush();
            } 

        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }
    public IActionResult AdminTest()
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
            try
            {
                sqlconnection.Open();

                SqlCommand sqlCommand = sqlconnection.CreateCommand();

                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "ViewAllUserExam";

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                ViewBag.Exam = sqlDataReader;
                return View();
            }
            catch (SqlException exception)
            {
                Log.Error(exception.ToString());
                return View();
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }

    public IActionResult Scorecard()
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
            try
            {
                sqlconnection.Open();

                SqlCommand sqlCommand = sqlconnection.CreateCommand();

                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "ViewScore";

                SqlParameter inputUserid = sqlCommand.Parameters.Add("@InUserID",SqlDbType.VarChar);
                inputUserid.Direction = ParameterDirection.Input;
                inputUserid.Value = HttpContext.Session.GetString("MainUserID");

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                ViewBag.Score = sqlDataReader;
                return View();
            }
            catch (SqlException exception)
            {
                Log.Error(exception.ToString());
                return View();
            }
            finally
            {
                Log.CloseAndFlush();
            } 
        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }

    public IActionResult AdminScorecard()
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
            try
            {
                sqlconnection.Open();

                SqlCommand sqlCommand = sqlconnection.CreateCommand();

                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "ViewAllUserScore";

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                ViewBag.Score = sqlDataReader;
                return View();
            }
            catch (SqlException exception)
            {
                Log.Error(exception.ToString());
                return View();
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }

    public IActionResult AddScore()
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            return View();
        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }
    }
    [HttpPost]
    public IActionResult AddScore(GetUserData getUserData)
    {
        if(HttpContext.Session.GetString("MainUserID")!=null)
        {
            ViewBag.MainUserID=HttpContext.Session.GetString("MainUserID");
            ViewBag.UserID = getUserData.UserID;
            ViewBag.ExamModel = getUserData.ExamModel;
            ViewBag.SubjectName = getUserData.SubjectName;

            if(getUserData.Mark!=null)
            {
                SqlConnection sqlconnection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Database=mvc;Trusted_Connection=True");
                try
                {
                    sqlconnection.Open();

                    SqlCommand sqlCommand = sqlconnection.CreateCommand();

                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandText = "AddScore";

                    SqlParameter inputUserid = sqlCommand.Parameters.Add("@InUserID",SqlDbType.VarChar);
                    inputUserid.Direction = ParameterDirection.Input;
                    inputUserid.Value = getUserData.UserID;

                    SqlParameter inputExamModel = sqlCommand.Parameters.Add("@InExam",SqlDbType.VarChar);
                    inputExamModel.Direction = ParameterDirection.Input;
                    inputExamModel.Value = getUserData.ExamModel;

                    SqlParameter inputSubjectName = sqlCommand.Parameters.Add("@InSubject",SqlDbType.VarChar);
                    inputSubjectName.Direction = ParameterDirection.Input;
                    inputSubjectName.Value = getUserData.SubjectName;

                    SqlParameter inputMark = sqlCommand.Parameters.Add("@InMark",SqlDbType.VarChar);
                    inputMark.Direction = ParameterDirection.Input;
                    inputMark.Value = getUserData.Mark;

                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                    sqlDataReader.Close();

                    TempData["Score"]="Score Added Successfully!!";

                    return RedirectToAction("AdminScoreCard","Home");
                }
                catch (SqlException exception)
                {
                    Log.Error(exception.ToString());
                    return View();
                }
                finally
                {
                    sqlconnection.Close();
                    Log.CloseAndFlush();
                }
            }
            else
            {
                return View();
            }
        }
        else
        {
            ViewBag.MainUserID=null;
            return RedirectToAction("Login","Home");
        }        
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        ViewBag.MainUserID = null;
        return View("Login");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
