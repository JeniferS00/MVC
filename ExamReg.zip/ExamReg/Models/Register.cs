using System.ComponentModel.DataAnnotations;
namespace Application.Models;
public class Register
    {        
        [EmailAddress(ErrorMessage ="MailID not in proper format")]
        [Required(ErrorMessage="MailID is required.")]
        [Display(Name = "Email")]
        public string? UserID { get; set; }

        [Required(ErrorMessage="Name is required.")]
        [Display(Name = "Name")]
        public string? UserName { get; set; }

        [Phone]
        [Display(Name = "PhoneNumber")]
        [RegularExpression(@"^[6-9]{1}[0-9]{9}$",ErrorMessage = "Entered phone number format is not valid.")]
        [Required(ErrorMessage="Phone Number is required.")]
        public string? PhoneNumber { get; set; }

        
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        [StringLength(30, MinimumLength = 6)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$", ErrorMessage ="Minimum six characters, at least one uppercase letter, one lowercase letter, one number and one special character")]
        [Required(ErrorMessage="Password is required.")]
        public string? Password { get; set; }

        [Required(ErrorMessage = "Confirm Password is required")]    
        [DataType(DataType.Password)]    
        [Compare("Password", ErrorMessage = "Password and Confirm Password do not match")]
        public string? ConfirmPassword { get; set; }
    }