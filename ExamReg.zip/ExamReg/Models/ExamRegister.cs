using System.ComponentModel.DataAnnotations;
namespace Application.Models;
public class ExamRegister
    {
        public string? UserID { get; set; }
        public string? ExamModel { get; set; }
        public string? DepartmentName { get; set; }
        public string? SubjectName { get; set; }
    }


