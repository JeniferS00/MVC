namespace Application.Models;
public class GetUserData
{
    public string? UserID { get; set; }
    public string? ExamModel { get; set; }
    public string? SubjectName { get; set; }
    public string? Mark { get; set; }
}