using System.ComponentModel.DataAnnotations;
namespace Application.Models;
public class Login
    {
        
        [Required(ErrorMessage = "The email address is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string? UserID { get; set; }

        [Required(ErrorMessage="Please enter a password.")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        [StringLength(30, MinimumLength = 6)]
        public string? Password { get; set; }
    }